﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using BookStore.Models;
using BookStore.Data_Gateway;
using BookStore.ViewModels;

namespace BookStore.Controllers
{
    public class HomeController : Controller
    {
        private readonly DatabaseContext context;
       // private IEnumerable<object> booklist;

        public HomeController(DatabaseContext _context)
        {
            context = _context;
        }

      

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
       
        public IActionResult Register()
        {
            return View();
        }
        public IActionResult FeedBack()
        {
            return View();
        }
        public IActionResult AboutUs()
        {
            return View();
        }



        public IActionResult AddBook()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddBook(ProductInfo productinfo)
        {
            if (ModelState.IsValid) { 
                Product product = new Product()
            {
                BookName = productinfo.BookName,
                WritterName = productinfo.WritterName,
                Price = productinfo.Price,
                BookID = productinfo.BookID };

            ModelState.Clear();
            context.Product.Add(product);
            context.SaveChanges();
                ViewBag.Message = "Successfully Added" + productinfo.BookName;
            }


            return View();
        
        }
        public IActionResult BookList()
        {
            List<Product> booklist = context.Product.ToList();
            var sent = new List<ProductInfo>();
            int count = 1;
            foreach(var item in booklist)
            {
                ProductInfo productinfo = new ProductInfo()
                {
                    BookID =item.BookID,
                    BookName =item.BookName,
                    WritterName =item.WritterName,
                    Price =item.Price
                    
                   

                };
                productinfo.Serial = count;
                count++;
                sent.Add(productinfo);
            }
            return View(sent);

        }
       
        public IActionResult AddOrder()
        {
            

            return View();
        }
        [HttpPost]
        public IActionResult AddOrder(OrderInfo orderinfo)
        {
          // context.OrderInfo().Add(orderinfo);
            //context.SaveChanges();
            ModelState.Clear();

            return View();

        }

        /* [HttpPost]
         public IActionResult AddBook(Product product)
         {
             context.Product.Add(product);
             int c=context.SaveChanges();
             if (c > 0)
             {
                 ViewBag.Message = "Successfully Added" + product.BookName;
             }
             ModelState.Clear();
             return View();
         }*/

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
