﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class OrderTable

    {  [Key]
        public int OrderID { get; set; }

        [Required]
        public string OrderName { get; set; }

        [Required]
        public string CustomerName { get; set; }
         [Required]
        public string Address { get; set; }
        [Required]
        public int ContactNumber { get; set; }
        
    }
}
